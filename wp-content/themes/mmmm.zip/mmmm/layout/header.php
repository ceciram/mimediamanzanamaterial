<!DOCTYPE html>
<html ng-app="app" >
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Angular Material style sheet -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/css/materialize.min.css  ">
  <link rel="stylesheet" href=<?php echo get_site_url()."/wp-content/themes/mmmm/assets/style.css"; ?>>

</head>
<body ng-controller="mainController">
