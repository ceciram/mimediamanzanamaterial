<aside id="left-sidebar-nav">
    <ul id="slide-out" class="side-nav fixed top-general blue-grey darken-3">

        <li><a class="waves-effect" href="#!/recomendados" >
                <img class="icon-item"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_recomendamos.png" alt="">
                <span>Te Recomendamos</span></a>
        </li>

        <li><a class="waves-effect" href="#!/tegusta">
                <img class="icon-item"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_tegusta.png" alt="">
                <span>Jugar Te gusta</span></a>
        </li>

        <li><a class="waves-effect" href="#!/enlinea">
                <img class="icon-item"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_enlinea_verde.png" alt="">
                <span>En línea ahora</span></a></li>

        <li><a class="waves-effect" href="#!/favoritos">
                <img class="icon-item"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_estrella_amarilla.png" alt="">
                <span>Favoritos</span></a>
        </li>

        <li><a class="waves-effect" href="#!/chat">
                <i class="material-icons white-text hide-on-small-only">chat_bubble</i>
                <img class="icon-item hide-on-med-and-up"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_chat_azul.png" alt="">
                <span>Mensajes</span></a>
        </li>

        <li><a class="waves-effect" href="#!/invitaciones">
                <i class="material-icons white-text hide-on-small-only">person_add</i>
                <img class="icon-item hide-on-med-and-up"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_invitaciones.png" alt="">
                <span>Invitaciones</span></a>
        </li>

        <li><a class="waves-effect" href="#!/segustan">
                <i class="material-icons white-text hide-on-small-only">favorite</i>
                <img class="icon-item hide-on-med-and-up"src="http://mimediamanzana.pe/wp-content/themes/default-mobile/img/img-mobile/ico_ambos_segustan.png" alt="">
                <span>Ambos se gustan</span></a>
        </li>

    </ul>
    <a href="#" data-activates="slide-out" class="button-collapse"><i class="material-icons">menu</i></a>
</aside>