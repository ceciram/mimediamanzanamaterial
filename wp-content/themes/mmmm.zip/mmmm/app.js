/**
 * Created by DatingLatamSAC on 23/12/2016.
 */

var app = angular.module('app',["ngRoute"]);

app.controller('mainController', ['$scope', '$log', '$http', '$location', function($scope, $log, $http, $location) {

    $scope.loadJquery = function() {
        $('.dropdown-button').dropdown({
                inDuration: 300,
                outDuration: 225,
                constrain_width: false,
                hover: false,
                gutter: 0,
                belowOrigin: false
            }
        );

        // JS PARA EL CHAT
        function chatear() {
          setTimeout(function () {
              $('.layer-chat').fadeOut(1500);
          },500);

          setTimeout(function () {
              $('.menu-chat').fadeIn(1500);
          },500);
        }

        $('.chatear').click(function() {
          chatear();
        });

        var mediaquery = window.matchMedia("(max-width: 768px)");
        if (mediaquery.matches) {
           $('.mostrar-contactos').removeClass('disabled');
           $('.mostrar-contactos').addClass('white');

           $('.chatear').click(function() {
             chatear();
             opacidad();
             ocultarContactos();
           });

           $('#btn-mostrar-contactos').click(function () {
             mostrarContactos();
             opacidad();
           });
        } else {
          $('.mostrar-contactos').addClass('disabled');
        };

        function mostrarContactos() {
          $('#contactos').addClass('mover-right-contactos');
          $('#contactos').removeClass('mover-left-contactos');
        }

        function ocultarContactos() {
          $('#contactos').addClass('mover-left-contactos');
          $('#contactos').removeClass('mover-right-contactos');
        }

        function opacidad() {
          $('.opacity').show();
          $('.opacity').addClass('suave');
        }

        function ocultarContactos() {
          $('#contactos').removeClass('mover-right-contactos');
          $('#contactos').addClass('mover-left-contactos');
          $('.opacity').hide();
          $('.opacity').addClass('desaparecer');
        }

        $('.mostrar-contactos').click(function() {
            mostrarContactos();
            opacidad();
        });

        $('.opacity').click(function() {
          ocultarContactos();
        });
    };
}]);

app.controller('chatController', ['$scope', '$log', '$http', '$location', function($scope, $log, $http, $location) {
    setTimeout(function(){
        $scope.loadJquery();
    }, 0);
}]);

app.config(function($routeProvider) {

	$routeProvider
		.when("/", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/enlinea/enlinea.html",
			controller  : "mainController"
		})
		.when("/enlinea", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/enlinea/enlinea.html"
		})
		.when("/recomendados", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/recomendados/recomendados.html"
		})
		.when("/tegusta", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/tegusta/tegusta.html"
		})
		.when("/favoritos", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/favoritos/favoritos.html"
		})
		.when("/chat", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/chat/chat.html",
            controller  : "chatController"
		})
		.when("/invitaciones", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/invitaciones/invitaciones.html"
		})
		.when("/segustan", {
			templateUrl : "http://localhost/wordpress01/wp-content/themes/mmmm/segustan/segustan.html"
		})
		.otherwise({
			redirectTo: "/"
		});

});
